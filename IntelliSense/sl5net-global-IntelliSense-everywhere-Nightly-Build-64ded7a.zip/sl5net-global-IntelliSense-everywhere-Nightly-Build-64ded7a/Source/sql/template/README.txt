If this select here does not produce enough results there are still some selects in the script:
Source\Includes\gi-everywhere.inc.ahk about line 555

04.01.2019 13:18,   19-01-04_13-18

