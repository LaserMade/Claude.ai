REPLACE INTO words(wordindexed, word , count , wordreplacement , actionListID, lineNr)
VALUES ('TOOLTIPSEC LINEFILENAME|RR|TOOLTIP2SEC( "`N(" A_THISFUNC " " REGEXREPLACE(A_LINEFILE,".*\\") ":"  A_LINENUMBER ")" )|AHK|SEND,{CTRLDOWN}{LEFT 8}{CTRLUP}', 'ToolTipsec lineFileName|rr|ToolTip2sec( "`n(" A_ThisFunc " " RegExReplace(A_LineFile,".*\\") ":"  A_LineNumber ")" )|ahk|Send,{CtrlDown}{left 8}{CtrlUp}', '', '' , 1, 6); 

REPLACE INTO words(wordindexed, word , count , wordreplacement , actionListID, lineNr)
VALUES ('TIPSEC|RR|TOOLTIP2SEC( "`N(" A_THISFUNC " " REGEXREPLACE(A_LINEFILE,".*\\") ":"  A_LINENUMBER ")" )|AHK|SEND,{CTRLDOWN}{LEFT 8}{CTRLUP}', 'Tipsec|rr|ToolTip2sec( "`n(" A_ThisFunc " " RegExReplace(A_LineFile,".*\\") ":"  A_LineNumber ")" )|ahk|Send,{CtrlDown}{left 8}{CtrlUp}', '', '' , 1, 6);
