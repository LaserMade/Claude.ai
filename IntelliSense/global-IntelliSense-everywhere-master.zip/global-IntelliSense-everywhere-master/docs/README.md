﻿# global-IntelliSense-everywhere 

English: If you can not imagine what this is, watch this video or ask a friend what an intellisense is.

German: Wenn du dir nicht vorstellen kannst was dies ist, schaue dir dieses Video an oder Frage einen Freund was eine intellisense ist.

[![global IntelliSense everywhere examples windows autohotkey](https://img.youtube.com/vi/elLsl8lj0K8/0.jpg)](https://www.youtube.com/watch?v=elLsl8lj0K8)
